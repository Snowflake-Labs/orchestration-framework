from .xetroc import *

__doc__ = xetroc.__doc__
if hasattr(xetroc, "__all__"):
    __all__ = xetroc.__all__